package sociais;

import twitter4j.Status;
import twitter4j.Twitter;
import twitter4j.TwitterFactory;
import twitter4j.auth.AccessToken;
import twitter4j.conf.Configuration;
import twitter4j.conf.ConfigurationBuilder;

public class Aplicativo {

	public static void main(String[] args) {
		System.out.println("Iniciando");
		try {
			ConfigurationBuilder builder = new ConfigurationBuilder();
			builder.setOAuthConsumerKey("G45bqwx5hG7uSbsechB7sJgu0");
			builder.setOAuthConsumerSecret("WrFxO1WWFLukS6rkJ4uDnEL7UYVKfr7wQkT4dkYZkQIBw2xqXI");
			Configuration configuration = builder.build();
			TwitterFactory factory = new TwitterFactory(configuration);
			Twitter twitter = factory.getInstance();
			AccessToken accessToken = loadAccessToken();
			twitter.setOAuthAccessToken(accessToken);
			Status status = twitter.updateStatus("Ol� Twitter1!");
			System.out.println("Tweet postado com sucesso 1! [" +	status.getText() + "].");
		} catch (Exception e) {
			System.out.println("Erro: " + e.getMessage());
			//e.printStackTrace();
		}
	}
	
	private static AccessToken loadAccessToken(){
		String token = "826179104965812224-e6G6wqYM9mOMsPzWoYfnvJBXpzFZoCs";
		String tokenSecret = "H2RGI7pPx72XZoBDvtTeeXLwH9BEr3dNegVDOvZEqMxRV";
		return new AccessToken(token, tokenSecret);
	}
}
